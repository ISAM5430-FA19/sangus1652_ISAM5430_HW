﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5
{
    class Account
    {
            public string Name { get; set; }
            private decimal balance;
            private decimal finalBalance;
        public Account(String accountName, decimal initialBalance,decimal finalBalance)
        {
            Name = accountName;
            Balance = initialBalance;
            FinalBalance = finalBalance;
        }
        public decimal Balance
        {
            get
            {
                return balance;
            }
            private set
            {
                if (value > 0.0m)
                {
                    balance = value;
                }
            }
        }

        public decimal FinalBalance
        {
            get
            {
               return finalBalance ;
            }

            private set
            {
                if (finalBalance > balance)
                {
                    finalBalance=value;
                }
            }
        }
        public void Withdraw(decimal withdrawAmount)
        {
            if (withdrawAmount > balance)
            {
                finalBalance = balance;
            }
            else
            {
                finalBalance = Balance - withdrawAmount;
            }
        }
    }
}

