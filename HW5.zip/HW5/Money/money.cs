﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Money
{
    class money
    {
        private int _dollars ;
        private int _cents;

        public money(int dollars, int cents)
        {
            _dollars = dollars;
            _cents = cents;
        }

        public money(decimal money)
        {
            _dollars = (int)money;
            _cents = (int)((money - _dollars)) * 100;
        }

        public int getDollars()
        {
            return _dollars;
        }

        public int getCents()
        {
            return _cents;
        }

        public override string ToString()
        {
            String amount;
            amount = "Your amount is:" + "$" + _dollars + "." + _cents + "";
            return amount;

        }
        public money increment(money m)
        {
            money increment = new money(_dollars + m.getDollars(), _cents + m.getCents());
            return increment;
        }

        public money decrement(money m)
        {
            money decrement = new money(m.getDollars()-_dollars, _cents- m.getCents());
            return decrement;
        }

    }
}
