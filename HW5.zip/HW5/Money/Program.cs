﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Money
{
    class Program
    {
        static void Main(string[] args)
        {
            money money1 = new money(100, 50);
            money money2 = new money(540);
            money money3 = money1.increment(money1);
            money money4 = money1.decrement(money2);

            Console.WriteLine("The amount in money1:");
            Console.WriteLine(money1 + "\n");
            Console.WriteLine("The amount in money2:");
            Console.WriteLine(money2 + "\n");
            Console.WriteLine("The amount in money3:");
            Console.WriteLine(money3 + "\n");
            Console.WriteLine("The amount in money4:");
            Console.WriteLine(money4 + "\n");
            Console.WriteLine(money4);
            Console.ReadLine();
        }
    }
}
