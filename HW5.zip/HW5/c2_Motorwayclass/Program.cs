﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c2_Motorwayclass
{
    class Program
    {
        static void Main(string[] args)
        {
            var motor = new motorway("Cycle", "Road", 'E', "Smooth", 3, true, "TXLI");
            Console.WriteLine(motor + "\n");

            var motor1 = new motorway("Bike", true);
            Console.WriteLine(motor1 + "\n");

            var motor2 = new motorway("Air");
            Console.WriteLine(motor2 + "\n");
        }
    }
}
