﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c2_Motorwayclass
{
    class motorway
    {
        public enum IsToll
        {
            Yes,
            No,
            NA
        }
        public enum Directions
        {
            North,East,West,South,NA
        }
        public string Name { get; set;}
        public string motortype { get; set;}
        public char Direction { get; set;}
        public string Surface { get; set;}
        public int number_of_lanes { get; set;}
        public string name_party { get; set;}
        public bool Toll { get; set;}

        public motorway(string name, string type, char direction, string surface, int numberoflanes, bool toll,string party_name)
        {
            Name = name;
            motortype = type;
            Direction = direction;
            Surface = surface;
            number_of_lanes = numberoflanes;
            Toll = toll;
            party_name = name_party;
        }

       
        public motorway(string name)
        {
            Name = name;
        }

        public motorway (string name,bool toll)
        {
            Name = name;
            Toll = toll;
        }
        public motorway(string name,int numberoflanes)
        {
            Name = name;
            number_of_lanes = numberoflanes;
        }
        private IsToll ISTOLL()
        {
            switch (Toll)
            {
                case true:
                    {
                        return IsToll.Yes;
                    }
                case false:
                    {
                        return IsToll.No;
                    }
                default:
                    {

                        return IsToll.NA;
                    }
            }
        }

        private Directions Motordirections()
        {
            switch (Direction)
            {
                case 'N':
                    {
                        return Directions.North;
                    }
                case 'E':
                    {
                        return Directions.East;
                    }
                case 'S':
                    {
                        return Directions.South;
                    }
                case 'W':
                    {
                        return Directions.West;
                    }
                default:
                    {
                        return Directions.NA;
                    }

            }
        }
        private string lanesNumber()
        {
            return number_of_lanes.ToString();

        }
        public override string ToString()
        {
            return $"MotorwayName:{Name}\n" +
                $"Typeof Motor:{motortype}\n" +
                $"Direction:{Motordirections()}\n" +
                $"Surface:{Surface}\n" +
                $"Numberoflanes:{lanesNumber()}\n" +
                $"Toll:{ISTOLL()}\n";
        }
    }
}
