﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW5
{
    class AccountTest
    {
        static void Main(string[] args)
        {
            Account account1 = new Account("Jane Green", 500.00m, 20.00m);
            Console.Write("\n Enter withdrawal amount for account1: ");
            decimal withdrawalAmount = decimal.Parse(Console.ReadLine());
            account1.Withdraw(withdrawalAmount);
            Console.WriteLine($"{account1.Name}'s Initialbalance:{account1.Balance:C} and FinalBalance:{account1.FinalBalance:C}");
            Console.ReadLine();
        }
            
    }
}
