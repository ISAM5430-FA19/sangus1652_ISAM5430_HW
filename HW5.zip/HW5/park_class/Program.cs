﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace park_class
{
    class Program
    {
        static void Main(string[] args)
        {
            parkclass p = new parkclass("geetha", "newyork", "theme", "all", 94, 12, 12);
            p.namelocationtype("geetha", "newyork", "theme");
            p.namelocationfacilities("anjali", "chicago","all" );
            p.revenue(12,12);
            _ = p.costPerVisitor(940, 12);
            
        }
    }
}
