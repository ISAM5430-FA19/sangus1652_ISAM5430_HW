﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace park_class
{
    class parkclass
    {
        private string _namepark;
        private string _loaction;
        private string _typeof;
        private string _facility;
        private int _fee;
        private int _numberOfEmployees;
        private int _numberOfVisitors;
        private decimal _annualBudget;
        private string Nameloactiontype;
        private string Namelocationfacilities;
        private decimal cost;
        private decimal Revenue;
        

        public parkclass(string _name, string place, string _type, string facility, int fee, int numberOfVisitors,decimal annualBudget)
        {
            _name = _namepark;
            place = _loaction;
            facility = _facility;
            fee = _fee;
            
            numberOfVisitors = _numberOfVisitors;
            annualBudget = _annualBudget;
        }

        public string namelocationtype(string _namepark, string _loaction,string  _typeof)
        {
            Nameloactiontype= _namepark + _loaction + _typeof;
            return Nameloactiontype;

        }
        public string namelocationfacilities(string _namepark, string _loaction,string _facility)
        {
            string Namelocationfacilities = _namepark + _loaction + _facility;
            return Namelocationfacilities;

        }

        public decimal costPerVisitor(decimal _annualBudget,int _numberOfVisitors)
        {
            cost = _annualBudget / _numberOfVisitors;
            return cost;
        }

        public decimal revenue(decimal _fee, int _numberOfVisitors)
        {
            Revenue = _fee * _numberOfVisitors;
            return Revenue;
        }

       public override string ToString()
        {
            return $"namelocationtype:{Nameloactiontype}\n" +
                $"namelocationacilities:{Namelocationfacilities}\n" +
                $"cost is:{cost}\n" +
                $"revenue is:{Revenue}";
        }

    }
}
