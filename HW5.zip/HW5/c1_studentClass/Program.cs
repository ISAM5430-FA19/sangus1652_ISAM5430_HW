﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c1_studentClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student("Geetanjali","Sangu");
            Student student1 = new Student(7);
            student.GPA = 3.9m;
            student.major = "MIS";
            student.classification = "Engineering";
            Console.WriteLine($"The name of the student is:{student.firstname} {student.lastname}");
            Console.WriteLine($"GPA of the {student.firstname} {student.lastname} is {student.GPA}");
            Console.ReadLine();
        }
    }
}
