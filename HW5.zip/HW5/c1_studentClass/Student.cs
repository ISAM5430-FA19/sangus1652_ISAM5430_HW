﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c1_studentClass
{
    class Student
    {
        public int number;
        public string firstname;
        public string lastname;
        public decimal GPA { get; set; }
        public string classification { get; set; }
        public string major { get; set; }

        public Student(int ID)
        {
            number = ID;
        }

        public Student(string FirstName, string LastName)
        {
            firstname = FirstName;
            lastname = LastName;
        }
    }
}
