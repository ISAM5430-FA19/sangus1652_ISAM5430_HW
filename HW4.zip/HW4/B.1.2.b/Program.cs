﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._1._2.b
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
