﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._2._4.C
{
    class Program
    {
        static void Main(string[] args)
        {
            for (char c = 'A'; c <= 'H'; c++)
            {
                bool vowelA = c == 'A' || c == 'E';
                for (char s = 'A'; s <= 'H'; s++)
                {
                    bool vowelB = s == 'A' || s == 'E';
                     for (char z = 'A'; z <= 'H'; z++)
                     {
                        bool vowelC = z == 'A' || z == 'E';
                        int vowels = (vowelA ? 1 : 0) + (vowelB ? 1 : 0) + (vowelC ? 1 : 0);
                        if (vowels == 1 || vowels == 2)
                        {
                            Console.Write($"{c}{s}{z} ");
                        }
                     }      
                }

            }
            Console.ReadLine();
        }
    }
}
