﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8a
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                bool lastVowel=true;
                int count=0;
                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter))
                    break;
                else if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u')
                {
                    if (!lastVowel)
                    {
                        count++;
                        lastVowel = true;
                    }
                    else
                    {
                        lastVowel = false;
                    }
                    if()
                }
                }
            }

            }
    }

