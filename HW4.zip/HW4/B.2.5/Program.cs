﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._2._5
{
    class Program
    {
        static void Main(string[] args)
        {
            for (char a = 'A'; a <= 'H'; a++)
            {
               bool vowelA = a == 'A' || a == 'E';
                {
                    for (char b = 'A'; b <= 'H'; b++)
                    {
                        bool vowelB = b == 'A' || b == 'E';
                        int vowel1 = (vowelA?1:0 )+( vowelB?1:0);
                        if (vowel1 >= 1)
                        {
                            Console.Write($"{a}{b} ");
                        }
                        for (char c = 'A'; c <= 'H'; c++)
                        {
                            bool vowelC = c == 'A' || b == 'E';
                            int vowel2 = (vowelA ? 1 : 0) + (vowelB ? 1 : 0) + (vowelC ? 1 : 0);
                            if (vowel2 >= 2)
                            {
                                Console.Write($"{a}{b}{c} ");
                            }

                        }
                    }
                }
                
            }
            Console.ReadLine();
        }
    }
}
