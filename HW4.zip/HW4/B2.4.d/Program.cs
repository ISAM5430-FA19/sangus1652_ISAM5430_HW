﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2._4.d
{
    class Program
    {
        static void Main(string[] args)
        {
            for (char c = 'A'; c <= 'H'; c++)
            {
                
                for (char s = 'A'; s <= 'H'; s++)
                {
                    if( s == 'A'|| s == 'E')
                    {
                        for (char z = 'A'; z <= 'H'; z++)
                        {

                            if (c != z)
                            {
                                Console.Write($"{c}{s}{z} ");
                            }
                        }

                    }
                   
                }

            }
            Console.ReadLine();
        }
    }
}
