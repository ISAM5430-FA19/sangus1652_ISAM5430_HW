﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._2._3.C
{
    class Program
    {
        static void Main(string[] args)
        {
            for (char c = 'A'; c <= 'H'; c++)
            {
                if (c == 'B' || c == 'C' || c == 'D' || c == 'F' || c == 'G' || c == 'H')
                {
                    for (char s = 'A'; s <= 'H'; s++)
                    {
                        if (s == 'A' || s == 'E')
                        {
                            Console.WriteLine($"{c}{s}");
                        }
                    }

                }
                   

            }
            Console.ReadLine();
        }
    }
}
