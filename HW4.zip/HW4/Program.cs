﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4
{
    class Program
    {
        static void Main(string[] args)
        {
            //B.1.1
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 5; j++)
                {
                    if (i != j)
                    {
                        Console.WriteLine(i + " " + j);
                    }

                }
            }
            //B.1.a
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine(i);
            }
           
            Console.ReadLine();
        }
    }
}
