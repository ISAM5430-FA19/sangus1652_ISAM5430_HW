﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4B
{
    class Program
    {
        static void Main(string[] args)
        {
            for (char c = 'A'; c <= 'H'; c++)
            {
                    for (char s = 'A'; s <= 'H'; s++)
                    {
                        if (c == 'A' || c == 'E'||s == 'A' || s == 'E')
                        {
                            Console.WriteLine($"{c}{s}");
                        }       
                    }
                  
            }
            Console.ReadLine();
        }
    }
}
