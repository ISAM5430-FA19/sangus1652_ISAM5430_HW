﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C9a
{
    class Program
    {
        static void Main(string[] args)
        {
            char previous =' ';
            bool increasing = false;
            bool musical = false;
            bool secondHalf = false;
            bool alternateVowels_Consonants = false;
            bool smooth = false;
            int difference = 0;
            bool alternating_orders = false;
            int diff = 0;
            int prev_diff = 0;
            int char_Count = 0;
           // bool alternating_order = false;
            while (true)
            {

                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter))
                    break;
                else
                {
                    //increasing order
                    if (char_Count == 0)
                    {
                        previous = letter;
                    }
                    else
                    {
                        if (previous < letter)
                        {
                            increase = true;
                        }
                        else
                        {
                            increase = false;
                        }
                    }
                    previous = letter;
                    char_Count++;
                    //musical
                    if (letter >= 'A' || letter <= 'G')
                    {
                        musical = true;
                    }
                    else
                    {
                        musical = false;
                    }
                    // second half of the alphabets
                    if (letter > 'N' && letter < 'Z')
                    {
                        secondHalf = true;
                    }
                    else
                    {
                        secondHalf = false;
                    }
                    //alternate vowel and consonant
                    if (letter == 'A' || letter == 'E' || letter == 'I' || letter == 'o'
                        || letter == 'u' || letter == 'Y' && (letter + 1 != 'A' ||
                        letter + 1 != 'E' || letter + 1 != 'I' || letter + 1 != 'o'
                        || letter + 1 != 'u' || letter + 1 != 'Y'))
                    {
                        alternateVowels_Consonants = true;
                    }
                    else
                    {
                        alternateVowels_Consonants = false;
                    }
                    //smooth transitions
                    diff = previous - letter;
                    if (diff == 1 || diff == 0)
                    {
                        smooth = true;
                    }
                    else
                    {
                        smooth = false;
                    }
                    previous = letter;
                }

            }
            Console.WriteLine("If letters in increasing order:" + increasing);
            Console.WriteLine("Can play on musical instrumnet:" + musical);
            Console.WriteLine("Do letters lie in second half:" + secondHalf);
            Console.WriteLine("Are characters alternate vowels and consonants:" + alternateVowels_Consonants);
            Console.WriteLine("Is smooth transition:" + smooth);
            Console.WriteLine("If letters in alternating order:" + alternating_orders);
            Console.ReadLine();
        }
    }
}
