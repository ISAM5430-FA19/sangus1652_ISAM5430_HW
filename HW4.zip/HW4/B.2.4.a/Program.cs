﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._2._4.a
{
    class Program
    {
        static void Main(string[] args)
        {
            //Atleast One vowel
            for (char c = 'A'; c <= 'H'; c++)
            {
                for (char s = 'A'; s <= 'H'; s++)
                {
                    for (char z = 'A'; z <= 'H'; z++)
                    {
                        if (c == 'A' || c == 'E' || z == 'A' || z == 'E' || s == 'A' || s == 'E')
                        {
                            Console.WriteLine($"{c}{s}{z}");
                        }
                    }
                }

            }
            Console.WriteLine();
            
            //Middle letter shoild be Vowel
            for (char c = 'A'; c <= 'H'; c++)
            {
                for (char s = 'A'; s <= 'H'; s++)
                {
                    if (s == 'A' || s == 'E')
                    {
                        for (char z = 'A'; z <= 'H'; z++)
                        {

                            Console.WriteLine($"{c}{s}{z}");

                        }
                    }
                       
                }

            }
            Console.ReadLine();
        }
    }
}
