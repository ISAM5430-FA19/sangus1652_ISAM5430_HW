﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B1._1.C
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int product = 1;
            int i = 0, j = 0, k = 0;
            for (i = 1; i <= 5; i++)
            {
                for (j = 1; j <= 5; j++)
                {
                    if (i != j)
                    {
                        product = i * j;
                        sum = sum + product;
                    }

                }
            }
            Console.WriteLine(sum);

            for (i = 1; i <= 5; i++)
            {
                for (j = 1; j <= 5; j++)
                {
                    if (i != j)
                    {
                        for (k = 1; k <= 5; k++)
                        {
                            if (k != j && k != i)
                            {
                                //Console.WriteLine(i + " " + j + " " + k);
                                //product = i * j* k;
                                sum += i * j * k;

                            }
                            else
                            {
                                continue;
                            }
                        }
                       
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }
}
