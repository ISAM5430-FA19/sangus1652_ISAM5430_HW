﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C6
{
    class Program
    {
        static void Main(string[] args)
        {
            //count of letters
            int count = 0;
            while (true)
            {

                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter))
                    break;
                else
                {
                    count++;
                }
            }
            Console.WriteLine("The count of letters is:"+count);

            int vowelCount = 0;
            int consonantCount = 0;
            while (true)
            {

                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter))
                    break;
                else if (letter == 'A' || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'U' || letter == 'Y')
                {
                    vowelCount++;
                }
                else
                {
                    consonantCount++;
                }
            }
            Console.WriteLine("Vowel count is:"+vowelCount);
            Console.WriteLine("Consonant count is:"+consonantCount);
            Console.ReadLine();
        }
    }
}
