﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int primenumber = int.Parse(Console.ReadLine());
            bool isTrue = true;
            for (int i = 2; i <= primenumber; i++)
            {
                for (int j = 2; j <= primenumber; j++)
                {
                    if (i != j && i % j == 0)
                    {
                        isTrue = false;
                        break;
                    }
                }
                if (isTrue)
                {
                    Console.Write(i);
                }
                isTrue = true;     
            }
            Console.ReadLine();
        }
    }
}
