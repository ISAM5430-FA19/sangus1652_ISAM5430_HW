﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sequence_IncreasingNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the list of numbers");
            int number = 0;
            //int previous = 0;
            int max_value = int.MinValue;
            while (true)
            {
                number = int.Parse(Console.ReadLine());
                //previous = number;
                if (number>=max_value)
                {
                        max_value = number;   
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine($"The maximum value is{max_value}");
            Console.ReadLine();
        }
    }
}
