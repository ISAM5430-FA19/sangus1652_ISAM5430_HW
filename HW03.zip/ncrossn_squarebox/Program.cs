﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ncrossn_squarebox
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the side of a square");
            int side = int.Parse(Console.ReadLine());
            for (int i = 1; i <= side; i++)
            {
                for (int j = 1; j <= side; j++)
                {
                    Console.Write("X");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
