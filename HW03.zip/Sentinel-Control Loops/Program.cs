﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sentinel_Control_Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the count of scores");
            int count = int.Parse(Console.ReadLine());
            int sum = 0;
            float average = 0;
            int minvalue = 0;
            int bestscore = 0;
            for (int i = 1; i <= count; i++)
            {
                
                int num = int.Parse(Console.ReadLine());
                bestscore = int.MinValue;
                if (num > bestscore)
                {
                    bestscore = num;
                }
                if (num > 0 && num <= 100)
                {
                    sum = sum + num;
                }
                else if (num == 0 || num < 100 || num >= 100)
                {
                    Console.WriteLine("Invalid score entered");
                }
                    
            }
            average = (int)sum / count;
            Console.WriteLine("The sum is : "+sum);
            Console.WriteLine("The avearge is :"+average);
           Console.WriteLine("The best score is:"+bestscore);
            Console.ReadLine();
        }
    }
}
