﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decimal_to_Binary_Conversion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the positive integer");
            int number = int.Parse(Console.ReadLine());
            int binaryNumber = 0;
            int count = 0;
            int remainder = 0;
            while (number!=0)
            {
                remainder = number % 2;
                int c = (int)Math.Pow(10, count);
                binaryNumber =binaryNumber + ( remainder * c);
                number = number / 2;
                count++;
            }
            Console.WriteLine(binaryNumber);
            Console.ReadLine();
        }
    }
}
