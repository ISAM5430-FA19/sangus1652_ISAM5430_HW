﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distance_ClosestnumberandItem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the item value");
            int item = int.Parse(Console.ReadLine());
            int min_distance = int.MaxValue;
            int number = 0;
            
            while (true)
            {
                Console.WriteLine("Enter the number");
                number = int.Parse(Console.ReadLine());
                if (number == item)
                {
                    break;
                }
                int distance = item-number;
                if (distance < min_distance)
                {
                    min_distance = distance;
                    Console.WriteLine($"The closest number is {number}");
                }   
            }
           // Console.ReadLine();

        }
    }
}
