﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace count_TillSquareofSmallest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the sequence of numbers");
            int number =0;
            int square_number = 0;
            int previous_number = 0;
            int min_number = int.MaxValue;
            while (true)
            {
                number = int.Parse(Console.ReadLine());
                previous_number = number;
                Console.WriteLine(number + "," + previous_number);
                if (number <= 0)
                {
                    break;
                }
                else if(number<min_number)
                {
                    min_number=number;
                    square_number = min_number * min_number;
                    if (number >= square_number)
                    {
                        Console.WriteLine(number);
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
