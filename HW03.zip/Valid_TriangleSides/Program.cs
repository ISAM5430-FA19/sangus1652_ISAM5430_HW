﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valid_TriangleSides
{
    class Program
    {
        static void Main(string[] args)
        {
            
            while (true)
            {
                Console.WriteLine("Enter the sides of the triangle");
                int side1 = int.Parse(Console.ReadLine());
                int side2 = int.Parse(Console.ReadLine());
                int side3 = int.Parse(Console.ReadLine());
                if (side1 <= 0 || side2 <= 0 || side3 <= 0)
                {
                    break;
                }
                else if (side1 + side2 > side3 && side2 + side3 > side1 && side3 + side1 > side2)
                {
                    Console.WriteLine("It is a valid triangle");
                }
                else
                {
                    Console.WriteLine("It is an invalid triangle");
                }
            }
            Console.ReadLine();
            

        }
    }
}
