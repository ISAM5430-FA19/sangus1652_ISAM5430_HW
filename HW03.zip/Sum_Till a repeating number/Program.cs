﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sum_Till_a_repeating_number
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the list of numbers");
            int sum = 0;
            int number = 0;
            int previous = 0;
            while (true)
            {
                number = int.Parse(Console.ReadLine());
                if (previous == number)
                {
                    break;
                }
                else
                {
                    previous = number;
                    sum = sum + previous;
                }

            }
            
            Console.WriteLine($"The sum is {sum}");
            Console.ReadLine();
        }
    }
}
