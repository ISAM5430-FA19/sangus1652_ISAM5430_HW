﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ENter the count");
            int count = int.Parse(Console.ReadLine());
            for (int i = 0; i <= count; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n");
            for (int j = count; j >= 0; j--)
            {
                for (int k = j; k >= 0; k--)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n");
            for (int i = count; i>=1; i--)
            {
                for (int k = count; k>i; k--)
                {
                    Console.Write(" ");
                }
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine(" ");
            }
            Console.WriteLine("\n");
            for (int i = count; i>=1; i--)
            {
                for (int j=1; j<i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = count; k>=i;k--)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n");
            Console.ReadLine();
        }
    }
}
